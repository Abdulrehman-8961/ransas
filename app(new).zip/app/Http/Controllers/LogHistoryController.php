<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class LogHistoryController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'verified','isAdmin']);
    }

    public function index()
    {
        return view("log-history");
    }

}
