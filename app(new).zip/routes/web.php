<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AddEventController;
use App\Http\Controllers\CalendarController;
use App\Http\Controllers\LogHistoryController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect('/Home');
});


Auth::routes();
Route::get('/Home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::post('/payment', [App\Http\Controllers\HomeController::class, 'payment']);
Route::get('/payment_success', [App\Http\Controllers\HomeController::class, 'successFunction']);

// Employee
Route::get('/Users', [UserController::class, 'view']);
Route::get('/User/add', [UserController::class, 'add']);
Route::post('/User/save', [UserController::class, 'save']);
Route::get('/User/edit/{id}', [UserController::class, 'edit']);
Route::post('/User/update/{id}', [UserController::class, 'update']);
Route::post('/User/update-password/{id}', [UserController::class, 'update_password']);
Route::get('/User/delete/{id}', [UserController::class, 'delete']);

// Add event

Route::get('/Add-Event', [AddEventController::class, 'index']);
Route::post('/Event/save', [AddEventController::class, 'save']);
Route::get('/check-availablity', [AddEventController::class, 'checkAvailability']);



// Calendar

Route::get('/Calendar', [CalendarController::class, 'index']);
Route::get('/get-events', [CalendarController::class, 'getEvents']);
Route::post('/Event-update/{id}', [CalendarController::class, 'updateEvents']);

// log and history

Route::get('/Log-History', [LogHistoryController::class, 'index']);

// Coron

Route::get('/Cron-Sms-Reminder', [App\Http\Controllers\CoronController::class, 'smsReminder']);
Route::get('/Cron-Payment-Status', [App\Http\Controllers\CoronController::class, 'checkPaymentStatus']);
