<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Auth;

class CoronController extends Controller
{
    public function smsReminder(){
        $currentDateTime = Carbon::now();
        $next24Hours = $currentDateTime->copy()->addHours(24)->toDateTimeString();

        $events = DB::table('events')
            ->where(DB::raw("CONCAT(start_date, ' ', start_time)"), '>=', $currentDateTime->toDateTimeString())
            ->where(DB::raw("CONCAT(start_date, ' ', start_time)"), '<=', $next24Hours)
            ->where('reminder',0)
            ->get();

            // dd($events);

            foreach ($events as $row) {
                $message = <<<EOT
                    Reminder:
                    You have a booking:
                    Type: {$row->booking_type}
                    Payment Status: {$row->payment_status}
                    Date: {$row->start_date} - {$row->end_date}
                    Time: {$row->start_time} - {$row->end_time}
                EOT;
                try {
                    $response = Http::withHeaders([
                        'Content-Type' => 'application/json',
                        'Authorization' => 'Basic aXN3aW0uY28uaWw6MWQzOGI2ODYtODA1OC00NDcxLWFkYjMtZWQzNDM3MDE3Njhl',
                    ])->post('https://capi.inforu.co.il/api/v2/SMS/SendSms', [
                        "Data" => [
                            "Message" => $message,
                            "Recipients" => [
                                [
                                    "Phone" => "0542165091"
                                ]
                            ],
                            "Settings" => [
                                "Sender" => "Ransas"
                            ]
                        ]
                    ]);
                } catch (\Throwable $th) {
                    //throw $th;
                }
                DB::table('events')->where('id',$row->id)->update([
                    'reminder' => 1
                ]);
            }
    }

    public function checkPaymentStatus(){
        $events = DB::table('events')->where('payment_method', 'Card')->where('payment_status','Paid')->where('sumit_payment_id', '!=', 'null')->get();
        foreach ($events as $row) {
            $response = Http::post('https://api.sumit.co.il/billing/payments/get/', [
                'Credentials' => [
                    'CompanyID' => 330173225,
                    'APIKey' => 'MAEGtAtdLD4hLBvfT8sKqGGCuvuxXWzB2cfoz52UmhDMcXqGdy'
                ],
                'PaymentID' => $row->sumit_payment_id
            ]);

            // You can then handle the response accordingly
            $responseData = $response->json();
            if ($responseData['Data']['Payment']['Status'] == "000" && $responseData['Data']['Payment']['ValidPayment'] == true) {
                dd($responseData);
                DB::table('events')->where('id',$row->id)->update([
                    'payment_status' => 'Paid',
                ]);

            }
        }
    }

}
